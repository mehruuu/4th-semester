def get_fashion_reply(user_input):
    user_input = user_input.lower()

    # Greetings and small talk
    if any(word in user_input for word in ["hi", "hello", "hey", "good morning", "good evening"]):
        return "Hey there! 👋 Welcome to the Fashion House. How can I help you today?"
    elif "how are you" in user_input:
        return "I'm just a stylish bot, but I'm always in fashion! How can I assist you today?"
    elif "thank you" in user_input or "thanks" in user_input:
        return "You're welcome! 😊 Need help with another look?"
    elif "sorry" in user_input:
        return "No worries! I'm here to help you with any fashion-related questions. 💅"
    elif "bye" in user_input or "goodbye" in user_input:
        return "Goodbye! Stay fabulous and fashionable! 💃✨"
    
    # Occasion-based recommendations
    if "wedding" in user_input:
        return "Try a sleek sherwani(male), a beautiful lehenga(female), or a designer gown for a wedding!"
    elif "party" in user_input or "club" in user_input:
        return "How about a glitter dress(female), cocktail attire(male), or a smart blazer with chinos(female)?"
    elif "funeral" in user_input:
        return "A respectful black or dark formal outfit is most appropriate for funerals."
    elif "breakup" in user_input:
        return "Go for something comfy and empowering — oversized hoodies, bold streetwear, or denim."
    elif "casual" in user_input:
        return "T-shirts, joggers, denim jackets, or comfy dresses make great casual wear!"
    elif "night" in user_input or "sleep" in user_input:
        return "Silky pajamas, cozy nightgowns, or loungewear sets are perfect for nightwear."
    elif "office" in user_input or "formal" in user_input:
        return "Consider formal shirts, blazers, pencil skirts, or business suits for the office."
    elif "interview" in user_input:
        return "A clean-cut suit or blouse with tailored pants is perfect for job interviews."
    elif "gym" in user_input or "fitness" in user_input:
        return "Go with breathable workout gear — leggings, dry-fit tops, or tracksuits."
    elif "beach" in user_input or "vacation" in user_input:
        return "Think swimsuits, kaftans, floral shirts, shorts, and sun hats for a beach vibe!"
    elif "date" in user_input:
        return "Wear something stylish yet comfortable — a nice dress, casual blazer, or trendy outfit."
    elif "travel" in user_input:
        return "Choose comfortable and layered clothes — hoodies, sneakers, joggers, or athleisure."
    elif "college" in user_input or "university" in user_input:
        return "Opt for trendy casuals like graphic tees, jeans, sneakers, and backpacks."
    elif "winter" in user_input or "cold" in user_input:
        return "Layer up with coats, scarves, boots, and woolen wear for winter days!"
    elif "summer" in user_input or "hot" in user_input:
        return "Stay cool with linen shirts, flowy dresses, shorts, and sandals."
    elif "spring" in user_input:
        return "Florals, light cardigans, and pastel outfits are great for spring!"
    elif "autumn" in user_input or "fall" in user_input:
        return "Earth-toned sweaters, boots, and light jackets are autumn classics."
    elif "ethnic" in user_input or "traditional" in user_input:
        return "Consider sarees, kurtas, sherwanis, or anarkalis depending on your culture."

    # Default response
    return "Tell me the occasion or weather — like wedding, party, office, beach, gym, or winter — and I’ll recommend the perfect look! 👗👔"
